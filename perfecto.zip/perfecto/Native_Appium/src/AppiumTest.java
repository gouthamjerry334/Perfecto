import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.html5.*;
import org.openqa.selenium.logging.*;
import org.openqa.selenium.remote.*;
import org.openqa.selenium.Cookie.Builder;

import io.appium.java_client.*;
import io.appium.java_client.android.*;
import io.appium.java_client.ios.*;

import com.perfecto.reportium.client.ReportiumClient;
import com.perfecto.reportium.client.ReportiumClientFactory;
import com.perfecto.reportium.model.Job;
import com.perfecto.reportium.model.PerfectoExecutionContext;
import com.perfecto.reportium.model.Project;
import com.perfecto.reportium.test.TestContext;
import com.perfecto.reportium.test.result.TestResult;
import com.perfecto.reportium.test.result.TestResultFactory;

public class AppiumTest {
    
    public static void main(String[] args) throws MalformedURLException, IOException {
        System.out.println("Run started");
        
        String browserName = "mobileOS";
        String AppName = "io.perfecto.expense.tracker";
        DesiredCapabilities capabilities = new DesiredCapabilities(browserName, "", Platform.ANY);
        String host = "mobilecloud.perfectomobile.com";
        capabilities.setCapability("user", "perfectotest3@perfectomobile.com");
        capabilities.setCapability("password", "Welcome2104");
        capabilities.setCapability("deviceName", "SH43PWM00164");
        

        capabilities.setCapability("automationName", "Appium");    
        System.getProperties().put("http.proxyHost", "proxy.cognizant.com");
        System.getProperties().put("http.proxyPort", "6050");
        System.getProperties().put("https.proxyHost", "proxy.cognizant.com");
        System.getProperties().put("https.proxyPort", "6050");
        
        
        capabilities.setCapability("appPackage",AppName);
        PerfectoLabUtils.setExecutionIdCapability(capabilities, host);  
        AndroidDriver driver = new AndroidDriver(new URL("https://" + host + "/nexperience/perfectomobile/wd/hub"), capabilities);
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
       
        

        /////Native
        
        switchToContext(driver, "NATIVE_APP");
        driver.findElementByXPath("//*[@resource-id=\"io.perfecto.expense.tracker:id/login_email\"]").sendKeys("test@perfecto.com");
        
        switchToContext(driver, "NATIVE_APP");
        driver.findElementByXPath("//*[@resource-id=\"io.perfecto.expense.tracker:id/login_password\"]").sendKeys("test1234");
        
        driver.hideKeyboard();
        switchToContext(driver, "NATIVE_APP");
        driver.findElementByXPath("//*[@resource-id=\"io.perfecto.expense.tracker:id/login_login_btn\"]").click();
        
        
        //******** hybrid
        
     /*   switchToContext(driver, "WEBVIEW");
        driver.findElementByXPath("//*[@id=\"login_email\"]").sendKeys("test@perfecto.com");
        
        switchToContext(driver, "WEBVIEW");
        driver.findElementByXPath("//*[@id=\"login_password\"]").sendKeys("test123");
        
  
  
        switchToContext(driver, "WEBVIEW");
        driver.findElementByXPath("//*[@id=\"login_login_btn\"]").click();
        */
        
        
        
        
        
        
        
        
    
        
        
        
        
        
        
        
        
                 
        System.out.println("Run ended");
    }
    
    
    
    
    
    
   
    
    private static void switchToContext(RemoteWebDriver driver, String context) {
        RemoteExecuteMethod executeMethod = new RemoteExecuteMethod(driver);
        Map<String,String> params = new HashMap<String,String>();
        params.put("name", context);
        executeMethod.execute(DriverCommand.SWITCH_TO_CONTEXT, params);
    }
    
    private static String getCurrentContextHandle(RemoteWebDriver driver) {
        RemoteExecuteMethod executeMethod = new RemoteExecuteMethod(driver);
        String context =  (String) executeMethod.execute(DriverCommand.GET_CURRENT_CONTEXT_HANDLE, null);
        return context;
    }
    
    private static List<String> getContextHandles(RemoteWebDriver driver) {
        RemoteExecuteMethod executeMethod = new RemoteExecuteMethod(driver);
        List<String> contexts =  (List<String>) executeMethod.execute(DriverCommand.GET_CONTEXT_HANDLES, null);
        return contexts;
    }
    
}
